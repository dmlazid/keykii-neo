#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path.cwd()
JAVA = ROOT / "app/src/main/java/com/keykii/neo/KeyKiiService.java"
GRADLE = ROOT / "app/build.gradle"

if not JAVA.exists():
    raise SystemExit("ERROR: KeyKiiService.java not found. Run this from /workspaces/keykii-neo")

s = JAVA.read_text(encoding="utf-8")

if "import android.view.inputmethod.InputMethodManager;" not in s:
    anchor = "import android.view.inputmethod.InputConnection;"
    if anchor in s:
        s = s.replace(anchor, anchor + "\nimport android.view.inputmethod.InputMethodManager;", 1)
    else:
        m = re.search(r'(import android\.view\.inputmethod\.[^;]+;\n)', s)
        if m:
            s = s[:m.end()] + "import android.view.inputmethod.InputMethodManager;\n" + s[m.end():]
        else:
            raise SystemExit("ERROR: Could not place InputMethodManager import safely.")

method_match = re.search(
    r'(void\s+addBottomKey\s*\([^)]*\)\s*\{)(.*?)(\n\s*\})',
    s,
    flags=re.S
)

if not method_match:
    candidates = list(re.finditer(
        r'((?:private|public|protected)?\s*void\s+\w+\s*\([^)]*String\s+action[^)]*\)\s*\{)(.*?)(\n\s*\})',
        s, flags=re.S
    ))
    chosen = None
    for c in candidates:
        if "handleKey(action)" in c.group(2) and ("TextView" in c.group(2) or "Button" in c.group(2)):
            chosen = c
            break
    method_match = chosen

if not method_match:
    raise SystemExit("ERROR: Could not find the bottom-key builder safely. No source was changed.")

body = method_match.group(2)
marker = "KEYKII_SPACE_INPUT_PICKER_2911"

if marker not in s:
    click_patterns = [
        r'(\bkey\.setOnClickListener\s*\(\s*v\s*->\s*handleKey\(action\)\s*\)\s*;)',
        r'(\bbox\.setOnClickListener\s*\(\s*v\s*->\s*handleKey\(action\)\s*\)\s*;)',
        r'(\b[a-zA-Z_]\w*\.setOnClickListener\s*\(\s*v\s*->\s*handleKey\(action\)\s*\)\s*;)'
    ]
    found = None
    for pat in click_patterns:
        m = re.search(pat, body)
        if m:
            found = m
            break

    if not found:
        raise SystemExit("ERROR: Found key builder but not its click handler. No source was changed.")

    var = re.match(r'\s*([a-zA-Z_]\w*)\.', found.group(1)).group(1)

    addition = f'''
        // KEYKII_SPACE_INPUT_PICKER_2911
        {var}.setOnLongClickListener(v -> {{
            if ("SPACE".equals(action)) {{
                InputMethodManager imm =
                    (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {{
                    imm.showInputMethodPicker();
                    return true;
                }}
            }}
            return false;
        }});
'''
    body = body[:found.end()] + addition + body[found.end():]
    s = s[:method_match.start(2)] + body + s[method_match.end(2):]

JAVA.write_text(s, encoding="utf-8")

if GRADLE.exists():
    g = GRADLE.read_text(encoding="utf-8")
    g = re.sub(r'versionName\s+["\'][^"\']+["\']', 'versionName "2.9.11"', g, count=1)

    m = re.search(r'versionCode\s+(\d+)', g)
    if m:
        old = int(m.group(1))
        g = g[:m.start(1)] + str(old + 1) + g[m.end(1):]

    GRADLE.write_text(g, encoding="utf-8")

print("KeyKii 2.9.11 patch applied.")
print("Tap KeyKii space = normal space.")
print("Long-press KeyKii space = Android Change keyboard picker.")
print("Interface/layout was not changed.")
