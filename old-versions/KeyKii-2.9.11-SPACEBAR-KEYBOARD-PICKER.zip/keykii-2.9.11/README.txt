KeyKii Neo 2.9.11 - Spacebar Keyboard Picker Patch

Changes:
- Current KeyKii interface stays unchanged.
- Tap the KeyKii spacebar = normal space.
- Long-press the KeyKii spacebar = Android system "Change keyboard" picker.
- versionName is changed to 2.9.11 when possible.

Steps:
1. Upload this ZIP to the ROOT of the GitHub repository.
2. Open Codespaces and run git pull origin main.
3. Unzip this ZIP.
4. Run the included Python patcher.
5. Build the APK.
